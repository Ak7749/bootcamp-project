# Basic Token Swap Platform

## 📌 Project Title
**Basic Token Swap Platform**

## 💡 Project Description
A lightweight smart contract on Soroban that facilitates a 1-way token swap between two assets based on a predefined exchange rate. This platform allows users to convert one type of token into another easily without the complexity of a full decentralized exchange (DEX).

## 🎯 Project Vision
To create a minimal and user-friendly decentralized token swap interface, perfect for MVPs, prototypes, and small-scale asset conversions within closed ecosystems or testnets.

## ✨ Key Features
- Simple token swap logic using fixed exchange rates
- Readable and maintainable Soroban smart contract
- Easily integrable into broader dApp ecosystems
- Low resource and gas usage

## 🔍 Contract Details

### Contract Address: CBZB6CSJMD35SMC5Z4XOC5AMLQGL7IS5QZXDAVRHE6VSQXQIUWID4A3Q

### `set_rate(env, rate)`
Sets the exchange rate from Token A to Token B.  
> Note: In production, this should be limited to an admin.

### `get_rate(env) -> u64`
Returns the currently set exchange rate.

### `swap(env, from, amount) -> u64`
Swaps the given `amount` of Token A and returns the amount of Token B based on the current rate. Auth required.

---

> 🚀 Built on Stellar's Soroban Smart Contract Platform
