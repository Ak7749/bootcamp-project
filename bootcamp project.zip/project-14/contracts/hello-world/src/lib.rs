#![no_std]
use soroban_sdk::{contract, contractimpl, Address, Env, Symbol, symbol_short, log};

#[contract]
pub struct TokenSwapContract;

#[contractimpl]
impl TokenSwapContract {
    // Store the exchange rate (e.g., 1 TOKEN_A = X TOKEN_B)
    const EXCHANGE_RATE: Symbol = symbol_short!("RATE");

    // Set the exchange rate (admin-only logic not enforced for simplicity)
    pub fn set_rate(env: Env, rate: u64) {
        if rate == 0 {
            panic!("Rate must be greater than 0");
        }
        env.storage().instance().set(&Self::EXCHANGE_RATE, &rate);
        log!(&env, "Exchange rate set to {}", rate);
    }

    // Get current exchange rate
    pub fn get_rate(env: Env) -> u64 {
        env.storage().instance().get(&Self::EXCHANGE_RATE).unwrap_or(1)
    }

    // Swap tokens (pseudo logic for token swap demonstration)
    pub fn swap(env: Env, from: Address, amount: u64) -> u64 {
        from.require_auth();

        let rate: u64 = Self::get_rate(env.clone());
        let received = amount * rate;

        log!(&env, "Swapped {} token A for {} token B", amount, received);

        received
    }
}
